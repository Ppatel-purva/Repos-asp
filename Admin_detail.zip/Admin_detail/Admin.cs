﻿namespace Admin_detail
{
    public class Admin
    {
        public int Id { get; set; }
        public string? admin_id { get; set; }
        public string? admin_first_name { get; set; }
        public string? admin_last_name { get; set; }
        public string? admin_username { get; set; }
        public string? admin_password { get; set; }
        public string? admin_token { get; set; } 

    }
}
